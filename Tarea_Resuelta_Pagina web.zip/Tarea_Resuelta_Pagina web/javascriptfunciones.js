// script.js
function mostrarTelefono() {
  Swal.fire({
    title: 'Número de contacto',
    text: '+(01) 452-3970',
    icon: 'info',
    confirmButtonText: 'Cerrar'
  });
}
